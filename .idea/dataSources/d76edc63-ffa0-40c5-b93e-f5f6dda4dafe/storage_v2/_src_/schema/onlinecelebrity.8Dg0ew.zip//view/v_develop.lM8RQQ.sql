create view v_develop as
select `onlinecelebrity`.`celebrity`.`celebrityid`   AS `celebrityid`,
       `onlinecelebrity`.`celebrity`.`website`       AS `website`,
       `onlinecelebrity`.`celebrity`.`star`          AS `star`,
       `onlinecelebrity`.`celebrity`.`as_score`      AS `as_score`,
       `onlinecelebrity`.`celebrity`.`celebrityname` AS `celebrityname`,
       `onlinecelebrity`.`celebrity`.`email`         AS `email`,
       `onlinecelebrity`.`celebrity`.`youtube`       AS `youtube`,
       `onlinecelebrity`.`celebrity`.`youtube_star`  AS `youtube_star`,
       `onlinecelebrity`.`celebrity`.`facebook`      AS `facebook`,
       `onlinecelebrity`.`celebrity`.`ins`           AS `ins`,
       `onlinecelebrity`.`develop`.`d_way`           AS `d_way`,
       `onlinecelebrity`.`develop`.`d_remark`        AS `d_remark`,
       `onlinecelebrity`.`develop`.`d_principal`     AS `d_principal`,
       `onlinecelebrity`.`develop`.`d_status`        AS `d_status`,
       `onlinecelebrity`.`develop`.`addtime`         AS `addtime`
from (`onlinecelebrity`.`celebrity`
         join `onlinecelebrity`.`develop`
              on ((`onlinecelebrity`.`develop`.`c_id` = `onlinecelebrity`.`celebrity`.`celebrityid`)));

