create view v_cooperation as
select `onlinecelebrity`.`celebrity`.`celebrityid`   AS `celebrityid`,
       `onlinecelebrity`.`celebrity`.`website`       AS `website`,
       `onlinecelebrity`.`celebrity`.`star`          AS `star`,
       `onlinecelebrity`.`celebrity`.`as_score`      AS `as_score`,
       `onlinecelebrity`.`celebrity`.`celebrityname` AS `celebrityname`,
       `onlinecelebrity`.`celebrity`.`email`         AS `email`,
       `onlinecelebrity`.`celebrity`.`youtube`       AS `youtube`,
       `onlinecelebrity`.`celebrity`.`youtube_star`  AS `youtube_star`,
       `onlinecelebrity`.`celebrity`.`facebook`      AS `facebook`,
       `onlinecelebrity`.`celebrity`.`ins`           AS `ins`,
       `onlinecelebrity`.`cooperation`.`c_way`       AS `c_way`,
       `onlinecelebrity`.`cooperation`.`c_remark`    AS `c_remark`,
       `onlinecelebrity`.`cooperation`.`c_principal` AS `c_principal`,
       `onlinecelebrity`.`cooperation`.`c_channel`   AS `c_channel`,
       `onlinecelebrity`.`cooperation`.`c_status`    AS `c_status`,
       `onlinecelebrity`.`cooperation`.`addtime`     AS `addtime`
from (`onlinecelebrity`.`celebrity`
         join `onlinecelebrity`.`cooperation`
              on ((`onlinecelebrity`.`cooperation`.`c_id` = `onlinecelebrity`.`celebrity`.`celebrityid`)));

