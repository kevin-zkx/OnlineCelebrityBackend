create view v_sample as
select `onlinecelebrity`.`celebrity`.`celebrityid`   AS `celebrityid`,
       `onlinecelebrity`.`celebrity`.`website`       AS `website`,
       `onlinecelebrity`.`celebrity`.`celebrityname` AS `celebrityname`,
       `onlinecelebrity`.`celebrity`.`email`         AS `email`,
       `onlinecelebrity`.`sample`.`s_product`        AS `s_product`,
       `onlinecelebrity`.`sample`.`country`          AS `country`,
       `onlinecelebrity`.`sample`.`state`            AS `state`,
       `onlinecelebrity`.`sample`.`city`             AS `city`,
       `onlinecelebrity`.`sample`.`address`          AS `address`,
       `onlinecelebrity`.`sample`.`phone`            AS `phone`,
       `onlinecelebrity`.`sample`.`postcode`         AS `postcode`,
       `onlinecelebrity`.`sample`.`order`            AS `order`,
       `onlinecelebrity`.`sample`.`sample_date`      AS `sample_date`,
       `onlinecelebrity`.`sample`.`sign_for`         AS `sign_for`
from (`onlinecelebrity`.`celebrity`
         join `onlinecelebrity`.`sample`
              on ((`onlinecelebrity`.`sample`.`c_id` = `onlinecelebrity`.`celebrity`.`celebrityid`)));

