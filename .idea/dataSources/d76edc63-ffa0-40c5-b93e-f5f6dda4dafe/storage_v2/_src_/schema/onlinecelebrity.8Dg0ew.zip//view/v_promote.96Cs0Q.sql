create view v_promote as
select `onlinecelebrity`.`celebrity`.`celebrityid`                                                AS `celebrityid`,
       `onlinecelebrity`.`celebrity`.`website`                                                    AS `website`,
       `onlinecelebrity`.`celebrity`.`star`                                                       AS `star`,
       `onlinecelebrity`.`celebrity`.`as_score`                                                   AS `as_score`,
       `onlinecelebrity`.`celebrity`.`celebrityname`                                              AS `celebrityname`,
       `onlinecelebrity`.`celebrity`.`email`                                                      AS `email`,
       `onlinecelebrity`.`celebrity`.`youtube`                                                    AS `youtube`,
       `onlinecelebrity`.`celebrity`.`youtube_star`                                               AS `youtube_star`,
       `onlinecelebrity`.`celebrity`.`facebook`                                                   AS `facebook`,
       `onlinecelebrity`.`celebrity`.`ins`                                                        AS `ins`,
       `onlinecelebrity`.`promote`.`p_way`                                                        AS `p_way`,
       `onlinecelebrity`.`promote`.`p_remark`                                                     AS `p_remark`,
       `onlinecelebrity`.`promote`.`p_principal`                                                  AS `p_principal`,
       `onlinecelebrity`.`promote`.`p_status`                                                     AS `p_status`,
       `onlinecelebrity`.`promote`.`p_product`                                                    AS `p_product`,
       `onlinecelebrity`.`promote`.`product_cost`                                                 AS `product_cost`,
       `onlinecelebrity`.`promote`.`transfer_cost`                                                AS `transfer_cost`,
       (`onlinecelebrity`.`promote`.`product_cost` + `onlinecelebrity`.`promote`.`transfer_cost`) AS `sum_cost`,
       `onlinecelebrity`.`promote`.`url`                                                          AS `url`,
       `onlinecelebrity`.`promote`.`join_league`                                                  AS `join_league`
from (`onlinecelebrity`.`celebrity`
         join `onlinecelebrity`.`promote`
              on ((`onlinecelebrity`.`promote`.`c_id` = `onlinecelebrity`.`celebrity`.`celebrityid`)));

